"use client"

import React from 'react';
import AdminHomePage from './AdminHomePage';

const page = () => {
    return (
        <>
            <AdminHomePage />
        </>
    );
};

export default page;