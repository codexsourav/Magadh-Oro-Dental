import React from 'react';

const BookingView = () => {
    return (
        <>
            Coming Soon
        </>
    );
};

export default BookingView;