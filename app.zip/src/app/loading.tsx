

function loading() {
  return (
    <div className='page-loading'>
      <div className="loader"></div>
    </div>
  )
}

export default loading